#ifndef COMPAT_NAMESER_H
#define COMPAT_NAMESER_H 1

/* Compatibility header to avoid lots of #ifdef _WIN32's in includes.h */

#endif
